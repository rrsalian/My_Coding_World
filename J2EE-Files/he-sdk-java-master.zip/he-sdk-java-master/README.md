## HackerEarth Java API

### Get Started
1. Install Gradle from http://gradle.org/downloads
2. Set environment variables: GRADLE_HOME and JAVA_HOME. Add `export PATH=$PATH:GRADLE_HOME/bin` to ".bashrc".
3. Clone the repo and run `gradle build`.
