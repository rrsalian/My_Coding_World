#include <stdio.h>
#include <stdlib.h>
#include <vector>
using namespace std;
int main(){
    vector <int> ad;
    printf("Hello Sreeram');
    return 0;
}
